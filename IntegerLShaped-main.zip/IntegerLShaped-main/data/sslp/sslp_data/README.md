The SSLP SIPLIB instances should be downloaded from https://www2.isye.gatech.edu/~sahmed/siplib/sslp/sslp.html and unziped to this folder.
